#pragma once
#ifndef DENOMINATIONCURRENCY_H
#define DENOMINATIONCURRENCY_H

class DenominationCurrency
{

private:
	long _baseAmount = 0; // Base Amount of monetary money held
	

public:
	//Simple Getters and setters
	long GetBaseAmount();
	void SetBaseAmount(long baseAmount); 
	int GetCopper();
	int GetSilver();
	int GetGold();
	
	//Helper classes
	bool IsFull(); // Returns true the wallet is full
	bool IsEmpty();// returns true if the wallet is empty
	bool HasCopper(); // returns the amount of copper contained
	bool HasSilver();// returns the amount of silver contained
	bool HasGold();// returns the amount of gold contained

	void Add(int gold, int silver, int copper); 
	void Subtract(int gold, int silver, int copper);

	//changes the amount of money in the wallet to the highest or lowest amount
	void Empty();
	void Fill();

	//Calculates amount of each coin
	int CalculateCopper(long baseAmount);
	int CalculateSilver(long baseAmount);
	int CalculateGold(long baseAmount);


	const long MaxAmount = 999999999;
	
};






























#endif