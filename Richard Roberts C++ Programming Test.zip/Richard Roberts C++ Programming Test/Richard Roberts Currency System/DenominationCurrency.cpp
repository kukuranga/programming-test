#include "DenominationCurrency.h"
#include <cmath>

long DenominationCurrency::GetBaseAmount()
{
	return _baseAmount;
}

void DenominationCurrency::SetBaseAmount(long baseAmount)
{
	_baseAmount = baseAmount;

	if (_baseAmount > MaxAmount) _baseAmount = MaxAmount;
	if (_baseAmount < 0) _baseAmount = 0; 
}

int DenominationCurrency::GetCopper()
{
	return CalculateCopper(_baseAmount);
}

int DenominationCurrency::GetSilver()
{
	return CalculateSilver(_baseAmount);
}

int DenominationCurrency::GetGold()
{
	return CalculateGold(_baseAmount);
}

bool DenominationCurrency::IsFull()
{
	return _baseAmount == MaxAmount;
}

bool DenominationCurrency::IsEmpty()
{
	return _baseAmount == 0;
}

bool DenominationCurrency::HasCopper()
{
	return GetCopper() > 0 || GetGold() > 0 || GetSilver() > 0;
}

bool DenominationCurrency::HasSilver()
{
	return GetGold() > 0 || GetSilver() > 0;
}

bool DenominationCurrency::HasGold()
{
	return GetGold() > 0;
}

void DenominationCurrency::Add(int gold, int silver, int copper)
{
	SetBaseAmount(_baseAmount += (silver * 100));
	SetBaseAmount(_baseAmount += (gold * 10000));
	SetBaseAmount(_baseAmount += copper);

}

void DenominationCurrency::Subtract(int gold, int silver, int copper)
{
	SetBaseAmount(_baseAmount -= copper);
	SetBaseAmount(_baseAmount -= (silver * 100));
	SetBaseAmount(_baseAmount -= (gold * 10000));
}


void DenominationCurrency::Empty()
{
	SetBaseAmount(0);
}

void DenominationCurrency::Fill()
{
	SetBaseAmount(MaxAmount);
}

int  DenominationCurrency::CalculateCopper(long baseAmount)
{
	return std::floor(int(GetBaseAmount() - ((GetSilver() * 100) + ( GetGold() * 10000))));
}

int  DenominationCurrency::CalculateSilver(long baseAmount)
{
	return std::floor(int((GetBaseAmount() / 100) - (GetGold() * 100)));
}

int  DenominationCurrency::CalculateGold(long baseAmount)
{
	return std::floor(int(GetBaseAmount() / 10000));
}
