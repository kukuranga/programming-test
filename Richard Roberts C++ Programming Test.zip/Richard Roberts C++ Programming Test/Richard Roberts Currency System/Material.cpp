#include "Material.h"

void Material::Initialize(int value, long uid)
{
	_uid = uid;
	_value = value;

}
