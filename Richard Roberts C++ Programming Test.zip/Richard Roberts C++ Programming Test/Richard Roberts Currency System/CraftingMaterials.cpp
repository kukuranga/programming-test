#include <json/value.h>
#include <fstream>
#include "CraftingMaterials.h"

void CraftingMaterials::Initialize()
{
	std::ifstream people_file("people.json", std::ifstream::binary);
	people_file >> JsonMaterials;


	for (Json::Value::ArrayIndex i = 0; i != JsonMaterials.size(); i++)
	{
		Material mat;
		mat.Initialize(JsonMaterials[i]["Value"], JsonMaterials[i]["uid"])
		Materials.Insert(mat);
	}
}
