#pragma once
#ifndef MATERIAL_H
#define MATERIAL_H

class Material
{
public:
	//enum to determin item quality
	enum Quality {
		poor = 1,
		normal = 2,
		high = 3
	};

	long _uid;// uid for distinct this material
	Quality _quality; //actual quality of this material
	int _value; //value of this material

	void Initialize(int value, long uid);
};
#endif