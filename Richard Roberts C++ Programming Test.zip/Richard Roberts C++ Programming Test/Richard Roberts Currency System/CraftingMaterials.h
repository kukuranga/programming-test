#pragma once
#ifndef CRAFTINGMATERIALS_H
#define CRAFTINGMATERIALS_H
#include "Material.h"
#include <list>
#include <iostream>


class CraftingMaterials
{
public:
	void Initialize(); //Initializes all materials contained in json
	std::list<Material> Materials; //List of all materials initialized
	Json::Value JsonMaterials; //variable to hold json data

};


#endif