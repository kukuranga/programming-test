
#include <iostream>
#include "DenominationCurrency.h"

int main()
{
    DenominationCurrency Wallet;
    Wallet.Add(10,38,80);
    
    std::cout << Wallet.GetGold() << "\n";
    std::cout << Wallet.GetSilver() << "\n";
    std::cout << Wallet.GetCopper() << "\n";

}

